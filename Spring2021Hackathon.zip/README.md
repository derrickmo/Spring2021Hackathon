Overview
Project summary
Please provide a short (one paragraph) summary of your project. Consider this your elevator pitch.

Include the link to your Devpost project page here: Devpost

Authors
Name - Devpost ID – Penn email – GitHub
Name - Devpost ID – Penn email – GitHub
Name - Devpost ID – Penn email – GitHub
Usage
This section walks a prospective user through the process of installing and running the project on their local machine. The more detailed and the more accurate, the better. User-friendly instructions will entice prospective users (including judges) to engage more deeply with your project, which could improve your hackathon score.

Prerequisites
What prerequisites must be installed in order to run your project, and how do you install them?

Provide code samples in this fenced code block.
Installation
Give a step-by-step rundown of how to install your project.

State step 1.

Provide code samples in this fenced code block.
State step 2.

Provide code samples in this fenced code block.
Etc.

Deployment
Give a step-by-step rundown of how to use your project. Including screenshots in this section can be highly effective for highlighting specific features of your project.

State step 1.

Provide code samples in this fenced code block.
State step 2.

Provide code samples in this fenced code block.
Etc.

Additional information
Tools used
Which frameworks, libraries, or other tools did you use to create your project?

Tool 1 - Description (e.g. "Web framework used")
Tool 2 - Description
Tool 3 - Description
Acknowledgments
Use anyone else's code? Inspired by a particular project? List / link here.

Item 1
Item 2
Item 3
License
If desired, add a section for your license. Reference sites like https://choosealicense.com can help you choose which license meets your needs.

For example:

This package is licensed under the GNU General Public License v3.0 (GPL-3).
